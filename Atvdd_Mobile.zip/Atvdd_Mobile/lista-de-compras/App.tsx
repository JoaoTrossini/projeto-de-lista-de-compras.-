
import { useState } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';

import type { ItemDeCompra } from './types';
import Cabecalho from './components/Cabecalho';
import FormularioItem from './components/FormularioItem';
import ListaCompras from './components/ListaCompras';

export default function App() {
  const [itens, setItens] = useState<ItemDeCompra[]>([
    { id: '1', nome: 'Maçã', quantidade: 3 },
    { id: '2', nome: 'Arroz', quantidade: 1 },
    { id: '3', nome: 'Leite', quantidade: 2 },
  ]);

  function adicionarItem(nome: string, quantidade: number): void {
    const novoItem: ItemDeCompra = {
      id: Date.now().toString(),
      nome,
      quantidade,
    };

    setItens((listaAtual) => [...listaAtual, novoItem]);
  }

  function removerItem(id: string): void {
    setItens((listaAtual) =>
      listaAtual.filter((item) => item.id !== id)
    );
  }

  return (
    <SafeAreaView style={estilos.container}>
      <StatusBar style="dark" />

      <KeyboardAvoidingView
        style={estilos.conteudo}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <Cabecalho />

        <FormularioItem aoAdicionar={adicionarItem} />

        <View style={estilos.lista}>
          <ListaCompras
            itens={itens}
            aoRemover={removerItem}
          />
        </View>

        <View style={estilos.rodape}>
          <Text style={estilos.rodapeTexto}>
            {itens.length} {itens.length === 1 ? 'item' : 'itens'} na lista
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const estilos = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F8FA',
  },
  conteudo: {
    flex: 1,
  },
  lista: {
    flex: 1,
    marginTop: 4,
  },
  rodape: {
    alignItems: 'center',
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: '#E9ECF2',
    backgroundColor: '#FFFFFF',
  },
  rodapeTexto: {
    fontSize: 13,
    color: '#6B7280',
  },
});